Ash Greninja from Pokémon Rumble Rush ripped by DogToon64.

If used, give credit to Nintendo and Game Freak.

Credit to DogToon64 is optional, but would be nice.